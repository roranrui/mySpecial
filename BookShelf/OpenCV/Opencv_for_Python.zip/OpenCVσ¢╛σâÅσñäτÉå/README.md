# OpenCV图像处理

## 主要内容

* [图像的几何变换](section0.md)
* [图像的形态学转换](section1.md)
* [图像的平滑方法](section2.md)
* [直方图的方法](section3.md)
* [边缘检测的方法](section4.md)
* [模板匹配和霍夫变换的应用](section5.md)

