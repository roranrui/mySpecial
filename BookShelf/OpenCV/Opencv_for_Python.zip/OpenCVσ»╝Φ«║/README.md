# 1.OpenCV简介

# 主要内容

该章节主要介绍：

* [图像的起源和数字图像](section0.md)
* [OpenCV的简介及其部署方法](section1.md)
* [OpenCV中包含的主要模块。](section2.md)

