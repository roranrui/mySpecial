# 4. 图像特征提取与描述

# 主要内容

该章节的主要内容是：

* [图像的特征](section0.md)
* [Harris和Shi-Tomasi算法的原理及角点检测的实现](section1.md)
* [SIFT/SURF算法的原理及使用SIFT/SURF进行关键点的检测方法](section2.md)
* [Fast算法角点检测的原理角及其应用](section3.md)
* [ORB算法的原理，及特征点检测的实现](section3.md)

