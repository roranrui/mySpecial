# OpenCV基本操作

# **主要内容**

本章主要介绍图像的基础操作，包括：

* [图像的IO操作，读取和保存方法](section0.md)
* [在图像上绘制几何图形](section0.md)
* [怎么获取图像的属性](section0.md)
* [怎么访问图像的像素，进行通道分离，合并等](section0.md)
* [怎么实现颜色空间的变换](section0.md)
* [图像的算术运算](section1.md)

